package com.airhack.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.airhack.configuration.Producer;
import com.airhack.model.SensorData;
import com.airhack.service.CollectorAnalyserService;

@RestController
public class CollectorAnalyserController {

	@Autowired(required = true)
	CollectorAnalyserService cas;

	@Autowired 
	Producer producer; 
	public CollectorAnalyserService getCas() {
		return cas;
	}

	public void setCas(CollectorAnalyserService cas) {
		this.cas = cas;
	}
	
	@RequestMapping(value ="test", method=RequestMethod.GET)
	@ResponseBody
	public String test() {
		System.out.println("Hello");
		return null;
	}

	@RequestMapping(value = { "airhack/collector" }, method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public void addSensorDataGenerateAnalysedData(@RequestBody SensorData data) {

		HashMap<String, String> sensormapping = new HashMap<String, String>();
		sensormapping.put("1", "Zone 1");
		sensormapping.put("sensor2", "Zone 2");
		sensormapping.put("sensor3", "Zone 3");
		sensormapping.put("sensor12", "Zone 1");
		sensormapping.put("sensor22", "Zone 2");
		
		System.out.println(data.getPpm());
		System.out.println(data.getSensorId());
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date endDate = new Date();

		Calendar cal = Calendar.getInstance();
		cal.setTime(endDate);
		cal.add(Calendar.MINUTE, -15);
		Date startDate = cal.getTime();

		System.out.println(formatter.format(endDate));
		data.setTime(endDate);
		cas.addData(data);

		List<SensorData> ppms = cas.getDataByZoneTimeStamp(data.getSensorId(), startDate, endDate);

		int counter = 0;
		int sum = 0;

		for (SensorData ppm : ppms) {

			counter++;
			sum = sum + Integer.parseInt(ppm.getPpm());

		}

		int ppmvalue = sum / counter;

		if (ppmvalue > 26) {

			String zone = sensormapping.get(data.getSensorId());
			producer.sendMessage("purifierService.queue", "{\"PPM\":\""+data.getPpm()+"\"}" );
			producer.sendMessage("androidservice.queue", "{\"PPM\":\""+data.getPpm()+"\"}");
			// send zone to message queue
		}
		
		

	}
}
