package com.airhack.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airhack.dao.CollectorAnalyserDao;
import com.airhack.model.SensorData;

@Service
public class CollectorAnalyserServiceImpl implements CollectorAnalyserService {

	@Autowired(required = true)
	CollectorAnalyserDao cad;

	public void setCad(CollectorAnalyserDao cad) {
		this.cad = cad;
	}

	
	@Transactional
	public void addData(SensorData sd) {
		
		cad.addData(sd);
		
	}

	@Transactional
	public List<SensorData> getDataByZoneTimeStamp(String zone, Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		List<SensorData> ppm = cad.getDataByZoneTimeStamp(zone, startDate, endDate);
		return ppm;
	}


}
