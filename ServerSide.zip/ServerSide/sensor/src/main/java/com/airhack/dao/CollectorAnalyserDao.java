package com.airhack.dao;

import java.util.Date;
import java.util.List;

import com.airhack.model.SensorData;

public interface CollectorAnalyserDao {
	
	public void addData(SensorData sd);
	public List<SensorData> getDataByZoneTimeStamp(String zone, Date fromTime, Date toTime);

}

