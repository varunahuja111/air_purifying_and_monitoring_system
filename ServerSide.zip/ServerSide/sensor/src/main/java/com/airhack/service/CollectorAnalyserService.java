package com.airhack.service;

import java.util.Date;
import java.util.List;

import com.airhack.model.SensorData;

public interface CollectorAnalyserService {
	
	public void addData(SensorData sd);
	public List<SensorData> getDataByZoneTimeStamp(String zone, Date startDate, Date endDate);
}