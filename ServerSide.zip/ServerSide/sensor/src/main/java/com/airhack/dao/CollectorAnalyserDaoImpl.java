package com.airhack.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.airhack.model.SensorData;

@Repository
public class CollectorAnalyserDaoImpl implements CollectorAnalyserDao {
	
	@Autowired(required = true)	
	private SessionFactory sessionFactory;
		
		public void setSessionFactory(SessionFactory sf){
			this.sessionFactory = sf;
		}
	
		public void addData(SensorData sd) {
			
			System.out.println("Inside add data");
			Session session = this.sessionFactory.openSession();
			System.out.println(session);
			session.getTransaction().begin();
			session.persist(sd);
			session.getTransaction().commit();
			
		}

		public List<SensorData> getDataByZoneTimeStamp(String zone, Date fromTime, Date toTime) {
			// TODO Auto-generated method stub

			
			Session session = this.sessionFactory.openSession();
			return session.createQuery("FROM SensorData AS c WHERE c.sensorId = :zone AND c.time BETWEEN :stDate AND :edDate ")
			.setParameter("zone", zone)
			.setParameter("stDate", convertUtilToSql(fromTime))
			.setParameter("edDate", convertUtilToSql(toTime))
			.list();
			
		}
		
	    private static java.sql.Date convertUtilToSql(java.util.Date uDate) {
	        java.sql.Date sDate = new java.sql.Date(uDate.getTime());
	        return sDate;
	    }
	}
