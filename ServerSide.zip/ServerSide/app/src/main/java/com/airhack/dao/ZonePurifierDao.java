package com.airhack.dao;

import java.util.List;

import com.airhack.model.AppPurifier;
import com.airhack.model.Purifier;


public interface ZonePurifierDao {
	
	public void addPurifier(Purifier ap);

	public List<String> getSensorByZone(String zone);

}

