package com.airhack.pojo;

public class AndroidSensorData {
    
	private String ppm;
    private String status;

    public String getPpm() {
        return ppm;
    }

    public void setPpm(String ppm) {
		this.ppm = ppm;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
        return status;
    }


}