package com.airhack.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.airhack.model.AppPurifier;
import com.airhack.model.Purifier;

@Repository
public class ZonePurifierDaoImpl implements ZonePurifierDao {
	
	@Autowired(required = true )	
	private SessionFactory sessionFactory;
		
		public void setSessionFactory(SessionFactory sf){
			this.sessionFactory = sf;
		}

		public void addPurifier(Purifier zp) {
			// TODO Auto-generated method stub
			System.out.println("Inside add purifier");
			Session session = this.sessionFactory.openSession();
			System.out.println(session);
			session.getTransaction().begin();
			session.persist(zp);
			session.getTransaction().commit();
			
		}

		public List<String> getSensorByZone(String zone) {
			// TODO Auto-generated method stub
			
				List<String> sensors=new ArrayList<String>();
				Session session = this.sessionFactory.openSession();
				List<Object[]> a = session.createNativeQuery("select * from AppPurifier where zone = "+zone).getResultList();
				for(Object[] i:a)
				{
				String purifierId=(String) i[0];
				
				sensors.add(purifierId);
				}
				
				return sensors;	
		}
	}
