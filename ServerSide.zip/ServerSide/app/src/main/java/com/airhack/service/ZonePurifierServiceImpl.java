package com.airhack.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.airhack.dao.ZonePurifierDao;
import com.airhack.model.AppPurifier;
import com.airhack.model.Purifier;

@Service
public class ZonePurifierServiceImpl implements ZonePurifierService {

	@Autowired(required = true)
	ZonePurifierDao zpd;

	public ZonePurifierDao getZpd() {
		return zpd;
	}

	public void setZpd(ZonePurifierDao zpd) {
		this.zpd = zpd;
	}


	@Transactional
	public void addPurifier(Purifier zp) {
		// TODO Auto-generated method stub
		zpd.addPurifier(zp);
		
	}

	public List<String> getSensorByZone(String zone) {
		// TODO Auto-generated method stub
		List<String> sensors = zpd.getSensorByZone(zone);
		return null;
	}

}
