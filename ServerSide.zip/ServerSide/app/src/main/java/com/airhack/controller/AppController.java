package com.airhack.controller;

import com.airhack.service.ZonePurifierService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.swing.text.AbstractDocument.Content;

import com.airhack.model.*;
import com.airhack.pojo.AndroidSensorData;
import com.airhack.pojo.ForcastedData;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class AppController {

	
	@Autowired
	ZonePurifierService zas;

	public ZonePurifierService getZas() {
		return zas;
	}

	public void setZas(ZonePurifierService zas) {
		this.zas = zas;
	}

	@RequestMapping(value = {"airhack/getpurifierdata"},method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public void MapZoneToPurifier (@RequestBody Purifier data){
		
		  System.out.println(data.getPpmvalue());
		  System.out.println(data.getPstatus());
		  System.out.println(data.getPurifierId());
		
		  zas.addPurifier(data);
		  
	}
	
	@RequestMapping(value = {"airhack/analysedata"},method = RequestMethod.GET, produces="application/json")
	  public List<ForcastedData> AnalyseData(){
		
		List<ForcastedData> fl= new ArrayList<ForcastedData>();
		
			ForcastedData fd=new ForcastedData();
			fd.setDate("12 Aug 2019");
			fd.setPpm("25");
			fl.add(fd);
			
			ForcastedData fd1=new ForcastedData();
			fd1.setDate("13 Aug 2019");
			fd1.setPpm("20");
			fl.add(fd1);
			
			ForcastedData fd2=new ForcastedData();
			fd2.setDate("14 Aug 2019");
			fd2.setPpm("22");
			fl.add(fd2);
			
			ForcastedData fd3=new ForcastedData();
			fd3.setDate("15 Aug 2019");
			fd3.setPpm("29");
			fl.add(fd3);
			
			ForcastedData fd4=new ForcastedData();
			fd4.setDate("16 Aug 2019");
			fd4.setPpm("27");
			fl.add(fd4);
			
			for(ForcastedData fa:fl)
			{
				System.out.println(fa.getDate());
				System.out.println(fa.getPpm());
			}
			
		
		return fl;
	}
	
	
	@RequestMapping(value = {"airhack/test"},method = RequestMethod.GET, produces="application/json")
	  public @ResponseBody AndroidSensorData/*AndroidSensorData*/ FetchTest(){
		AndroidSensorData asd = new AndroidSensorData();
		asd.setPpm("26");
		asd.setStatus("on");
		return asd;
	}
	
	@RequestMapping(value = {"airhack/startpurifier"},method = RequestMethod.GET)
    @ResponseBody
    public void StartPurifier (@RequestParam("zone") String zone) {
        
		//List<String> sensors = zps.getSensorByZone(zone);
		
//		for (String sensor : sensors) {
//			
//			// code to turn on the sensors that come in the list
//	        
//		}
	
	}
	
	
	
}
