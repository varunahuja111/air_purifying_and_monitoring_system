package com.airhack.configuration;

import org.springframework.stereotype.Component;

import com.airhack.service.PpmStatus;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
//import com.airhack.configuration.*;
//
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;

@Component
public class Listener {
	
//	@Autowired(required = true)
//	private Producer producer;

	@JmsListener(destination = "androidservice.queue")
	public void receiveMessage(final Message jsonMessage) throws JMSException {
		String messageData = null;
		System.out.println("Received message " + jsonMessage);
		if(jsonMessage instanceof TextMessage) {
			TextMessage textMessage = (TextMessage)jsonMessage;
			messageData = textMessage.getText();
			PpmStatus.ppmvalue=messageData;
		}
//		producer.sendMessage("outbound.queue", messageData);
	}

}