package com.airhack.service;

import java.util.List;

import com.airhack.model.Purifier;



public interface AndroidService {
	
	public void addPurifier(Purifier ap);

	public List<String> getSensorByZone(String zone);
}