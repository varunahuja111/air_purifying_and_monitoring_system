package com.airhack.pojo;


public class ForcastData {
	
	private String date;
	private String ppm;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getPpm() {
		return ppm;
	}
	public void setPpm(String ppm) {
		this.ppm = ppm;
	}
	
	
	
}
