package com.airhack.dao;

import java.util.List;

import com.airhack.model.Purifier;


public interface AndroidDao {
	
	public void addPurifier(Purifier ap);

	public List<String> getSensorByZone(String zone);

}

