package com.airhack.controller;

import com.airhack.service.PpmStatus;
import com.airhack.service.AndroidService;

import java.util.ArrayList;
import java.util.List;


import com.airhack.model.Purifier;
import com.airhack.pojo.AndroidData;
import com.airhack.pojo.ForcastData;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class AppController {

	
	@Autowired(required = true)
	AndroidService zas;

	public AndroidService getZas() {
		return zas;
	}

	public void setZas(AndroidService zas) {
		this.zas = zas;
	}

	@RequestMapping(value = {"airhack/getpurifierdata"},method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public void MapZoneToPurifier (@RequestBody Purifier data){
		
		  System.out.println(data.getPpmvalue());
		  System.out.println(data.getPstatus());
		  System.out.println(data.getPurifierId());
		
		  zas.addPurifier(data);
		  
	}
	
	@RequestMapping(value = {"airhack/analysedata"},method = RequestMethod.GET, produces="application/json")
	  public List<ForcastData> AnalyseData(){
		
		List<ForcastData> fl= new ArrayList<ForcastData>();
		
			ForcastData fd=new ForcastData();
			fd.setDate("12 Aug 2019");
			fd.setPpm("25");
			fl.add(fd);
			
			ForcastData fd1=new ForcastData();
			fd1.setDate("13 Aug 2019");
			fd1.setPpm("20");
			fl.add(fd1);
			
			ForcastData fd2=new ForcastData();
			fd2.setDate("14 Aug 2019");
			fd2.setPpm("22");
			fl.add(fd2);
			
			ForcastData fd3=new ForcastData();
			fd3.setDate("15 Aug 2019");
			fd3.setPpm("29");
			fl.add(fd3);
			
			ForcastData fd4=new ForcastData();
			fd4.setDate("16 Aug 2019");
			fd4.setPpm("27");
			fl.add(fd4);
			
			for(ForcastData fa:fl)
			{
				System.out.println(fa.getDate());
				System.out.println(fa.getPpm());
			}
			
		
		return fl;
	}
	
	
	@RequestMapping(value = {"airhack/test"},method = RequestMethod.GET, produces="application/json")
	  public @ResponseBody AndroidData/*AndroidSensorData*/ FetchTest(){
		AndroidData asd = new AndroidData();
		asd.setPpm(PpmStatus.ppmvalue);//PpmStatus.ppmvalue);
		asd.setStatus("off");
		/*
		 * if(120<400)//Integer.parseInt(PpmStatus.ppmvalue)) { asd.setStatus("on"); }
		 * else { asd.setStatus("off"); }
		 */
		
		return asd;
	}
	
	
	
	
	@RequestMapping(value = {"airhack/startpurifier"},method = RequestMethod.GET)
    @ResponseBody
    public void StartPurifier (@RequestParam("zone") String zone) {
        
		//List<String> sensors = zps.getSensorByZone(zone);
		
//		for (String sensor : sensors) {
//			
//			// code to turn on the sensors that come in the list
//	        
//		}
	
	}
	
	
	
}
