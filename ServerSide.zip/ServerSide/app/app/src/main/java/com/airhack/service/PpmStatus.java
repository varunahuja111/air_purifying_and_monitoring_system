package com.airhack.service;

public class PpmStatus {

	public static String ppmvalue="87";
	
}
