package com.airhack.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.airhack.dao.AndroidDao;
import com.airhack.model.Purifier;

@Service
public class AndroidServiceImpl implements AndroidService {

	@Autowired(required = true)
	AndroidDao zpd;

	public AndroidDao getZpd() {
		return zpd;
	}

	public void setZpd(AndroidDao zpd) {
		this.zpd = zpd;
	}


	@Transactional
	public void addPurifier(Purifier zp) {
		// TODO Auto-generated method stub
		zpd.addPurifier(zp);
		
	}

	public List<String> getSensorByZone(String zone) {
		// TODO Auto-generated method stub
		List<String> sensors = zpd.getSensorByZone(zone);
		return sensors;
	}

}
