package com.airhack.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Purifier {
	
	@Id
	private String purifierId;
	
	private String pstatus;
	private String ppmvalue;
	public String getPurifierId() {
		return purifierId;
	}
	public void setPurifierId(String purifierId) {
		this.purifierId = purifierId;
	}
	public String getPstatus() {
		return pstatus;
	}
	public void setPstatus(String pstatus) {
		this.pstatus = pstatus;
	}
	public String getPpmvalue() {
		return ppmvalue;
	}
	public void setPpmvalue(String ppmvalue) {
		this.ppmvalue = ppmvalue;
	}
	
	
	
}
