package com.airhack.controller;

import com.airhack.model.ZonePurifier;
import com.airhack.service.PpmValue;
import com.airhack.service.ZonePurifierService;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class PurifierController {
	
	
	@Autowired(required = true)
	ZonePurifierService zps;

	public ZonePurifierService getZps() {
		return zps;
	}

	public void setZps(ZonePurifierService zps) {
		this.zps = zps;
	}

	@RequestMapping(value = {"airhack/mappurifier"},method = RequestMethod.POST,consumes = "application/json")
    @ResponseBody
    public void MapZoneToPurifier (@RequestBody ZonePurifier data){
		/*
		 * JSONParser parser = new JSONParser(); JSONObject jsonObject =
		 * (JSONObject)parser.parse(json); String zone =
		 * jsonObject.get("zone").toString(); String purifierId =
		 * jsonObject.get("purifierId").toString();
		 * 
		 * ZonePurifier zp = new ZonePurifier();
		 * 
		 * zp.setZone(zone); zp.setPurifierId(purifierId);
		 */
        
		System.out.println(data.getPurifierId());
		System.out.println(data.getZone());
		
        zps.addPurifier(data);
        
	}
	
	@RequestMapping(value = {"airhack/getlistpurifier"},method = RequestMethod.GET)
    @ResponseBody
    public String StartPurifier () {
        
		
		List<ZonePurifier> sensors=new ArrayList<ZonePurifier>();
		String z="zone1";
		sensors = zps.getSensorByZone(z);

		
		for (ZonePurifier sensor : sensors) {
			
			System.out.println(sensor.getZone());
			System.out.println(sensor.getPurifierId());
			
			// code to turn on the sensors that come in the list
			// send list to app servlet using message queue      
		}
		
		if(Integer.parseInt(PpmValue.ppmvalue)>120) {
			return "on";
		}
		else {
			return "off";
		}
		
		
	
	}
	
	
	
}
