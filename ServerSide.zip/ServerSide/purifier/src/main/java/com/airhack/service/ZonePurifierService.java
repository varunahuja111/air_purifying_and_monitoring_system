package com.airhack.service;

import java.util.List;

import com.airhack.model.ZonePurifier;;

public interface ZonePurifierService {
	
	public void addPurifier(ZonePurifier zp);

	public List<ZonePurifier> getSensorByZone(String zone);
}