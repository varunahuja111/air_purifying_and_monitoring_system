package com.airhack.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class ZonePurifier {
	
	@Id
	@Column(name="purifierId")
	private String purifierId;
	private String zone;
	
	public String getPurifierId() {
		return purifierId;
	}
	public void setPurifierId(String purifierId) {
		this.purifierId = purifierId;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
}
