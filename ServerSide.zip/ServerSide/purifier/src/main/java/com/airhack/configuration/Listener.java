package com.airhack.configuration;

import org.springframework.stereotype.Component;

import com.airhack.service.PpmValue;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;

@Component
public class Listener {
	
	@Autowired
	private Producer producer;

	@JmsListener(destination = "purifierService.queue")
	public void receiveMessage(final Message jsonMessage) throws JMSException {
		String messageData = null;
		System.out.println("Received message " + jsonMessage);
		if(jsonMessage instanceof TextMessage) {
			TextMessage textMessage = (TextMessage)jsonMessage;
			messageData = textMessage.getText();
			PpmValue.ppmvalue=messageData;
		}
//		producer.sendMessage("outbound.queue", messageData);
	}

}