package com.airhack.dao;

import java.util.List;

import com.airhack.model.ZonePurifier;

public interface ZonePurifierDao {
	
	public void addPurifier(ZonePurifier zp);

	public List<ZonePurifier> getSensorByZone(String zone);

}

