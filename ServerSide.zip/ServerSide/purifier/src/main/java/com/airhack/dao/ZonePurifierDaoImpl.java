package com.airhack.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.airhack.model.ZonePurifier;

@Repository
public class ZonePurifierDaoImpl implements ZonePurifierDao {
	
	@Autowired(required = true)
	private SessionFactory sessionFactory;
		
		public void setSessionFactory(SessionFactory sf){
			this.sessionFactory = sf;
		}

		public void addPurifier(ZonePurifier zp) {
			// TODO Auto-generated method stub
			System.out.println("Inside add purifier");
			Session session = this.sessionFactory.openSession();
			System.out.println(session);
			session.getTransaction().begin();
			session.persist(zp);
			session.getTransaction().commit();
			
		}

		public List<ZonePurifier> getSensorByZone(String zone) {
			// TODO Auto-generated method stub
			
				List<ZonePurifier> sensors=new ArrayList<ZonePurifier>();
				Session session = this.sessionFactory.openSession();
				List<Object[]> a = session.createNativeQuery("select * from zonepurifier where zone ='"+zone+"'").getResultList();
				
				for(Object[] i:a)
				{
				String purifierId=(String) i[0];
				String z=(String) i[1];
				ZonePurifier z1=new ZonePurifier();
				z1.setPurifierId(purifierId);
				z1.setZone(z);
				sensors.add(z1);
				}
				
				return sensors;	
		}
	}
