package com.airhack.service;

public class PpmValue {

	public static String ppmvalue;
	
	
}
