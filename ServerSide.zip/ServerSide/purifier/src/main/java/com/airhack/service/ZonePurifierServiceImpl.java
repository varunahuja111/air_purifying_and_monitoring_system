package com.airhack.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.airhack.dao.ZonePurifierDao;
import com.airhack.model.ZonePurifier;

@Service
public class ZonePurifierServiceImpl implements ZonePurifierService {

	@Autowired(required = true)
	ZonePurifierDao zpd;

	public ZonePurifierDao getZpd() {
		return zpd;
	}

	public void setZpd(ZonePurifierDao zpd) {
		this.zpd = zpd;
	}


	@Transactional
	public void addPurifier(ZonePurifier zp) {
		// TODO Auto-generated method stub
		zpd.addPurifier(zp);
		
	}

	public List<ZonePurifier> getSensorByZone(String zone) {
		// TODO Auto-generated method stub
		System.out.println(zone);
		List<ZonePurifier> sensors = zpd.getSensorByZone(zone);
		return sensors;
	}

}
